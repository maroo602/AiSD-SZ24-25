﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace MS
{
    internal class List
    {
        public NodeL head;
        public NodeL tail;
        public int count=0;
        void AddFirst(int liczba)
        {
            
        }
        NodeL AddLast(int liczba)
        {
            var tmp = new NodeL(7);
            tmp.p = this.tail;
            this.tail.n = tmp;
            this.tail = tmp;
            this.count++;
            return tmp;
            
        }
        /*
        NodeL RemoveFirst() { }
        NodeL RemoveLast() { }
        string ToString() //"3,8,7"
        {

        }
        */
    }
}
