using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] tab1 = { 8, 3, 7, 5, 2, 1, 4 };
            MS(tab1, 0, tab1.Length - 1);

        }
        private static void MS(int[] tab1, int p, int r) {
            if (p < r)
            {
                int q = (p + r) / 2;
                MS(tab1, p, q);
                MS(tab1, q + 1, r);
                SCAL(tab1, p, q, r);
            }
            
        
        }
        private static void SCAL(int[] tab1, int p, int r, int q)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}